package com.example.nathanchuludaproject2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddItemActivity extends AppCompatActivity {

    EditText name_input, qty_input;
    Button ati_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        name_input = findViewById(R.id.name_input);
        qty_input = findViewById(R.id.qty_input);
        ati_button = findViewById(R.id.ati_button);
        ati_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyDatabaseHelper myDB = new MyDatabaseHelper(AddItemActivity.this);
                myDB.addItem(name_input.getText().toString().trim(),
                        Integer.valueOf(qty_input.getText().toString().trim()));
            }
        });

    }
}